# Password

**Password** is a Python package for collecting user password input and allowing the input
to be masked or revealed in plain text. The password is then returned to be stored or used
for other purposes.
